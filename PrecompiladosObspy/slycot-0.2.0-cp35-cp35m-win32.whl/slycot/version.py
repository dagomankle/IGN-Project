
# THIS FILE IS GENERATED FROM SLYCOT SETUP.PY
short_version = '0.2.0'
version = '0.2.0'
full_version = '0.2.0'
git_revision = '203d4385d7d89037ee6e83c65494cb0a4b65f34a'
release = True

if not release:
    version = full_version
