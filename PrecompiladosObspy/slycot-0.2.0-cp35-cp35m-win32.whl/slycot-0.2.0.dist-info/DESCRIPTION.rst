Slycot wraps the SLICOT library which is used for control and systems analysis.



